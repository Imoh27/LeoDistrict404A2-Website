<footer class="footer text-right">
   <?php echo date('Y'); ?> © Powered by <a href="">Leo District 404A2 ICT & Data Management Team</a>.
</footer>


</body>

</html>