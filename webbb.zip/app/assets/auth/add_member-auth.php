<?php

include('includes/alt-config.php');

if (isset($_POST[''])) {
    # code...
}