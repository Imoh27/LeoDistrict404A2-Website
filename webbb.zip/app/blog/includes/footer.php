    <footer class="py-5 bg-dark" style="position: absolute; width:100%">
      <div class="container">
        <p class="m-0 text-center text-white">Copyright &copy; <?php echo date('Y'); ?> |  Calabar Paradise Lions Club</p>
      </div>
      <!-- /.container -->
    </footer>